import { Component, OnInit } from '@angular/core';
import * as c3 from 'c3';
import * as d3 from 'd3';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { TableComponent, USER } from '../table/table.component';
import { UsersService } from '../users.service';

export interface ClientData {
  ClientName: number;
  AnomalyType: string;
  Data: {
    ExecutionDate: string;
    NoOfTrxEachDay: number;
    IndividualAmount: number;
    AuthorizationDate: Date;
  }[];
}

@Component({
  selector: 'data-chart',
  templateUrl: './data-charts.component.html',
})
export class DataChartsComponent implements OnInit {
  // valueSubscription: Subscription;
  constructor(
    private $http: HttpClient,
    private usersService: UsersService) { };
  ngOnInit() {
    this.usersService.selectedUser.subscribe((user: any) => {
      console.log('Received value:', user);
      this.getClientData(user.ClientName);
    });

  }

  getClientData(id: any): void {
    this.$http.get(`http://localhost:3000/users/${id}`)
      .subscribe((data: any) => {
        const chartData = this.mapData(data);
        this.renderChart(chartData);
      },
        (error) => {
          console.error('Error fetching data:', error);
        })
  };

  mapData(clientData: ClientData) {
    let data: any = [];
    switch (clientData.AnomalyType) {
      case 'transactions':
        data = clientData.Data.map(e => {
          return {
            executionDate: new Date(Date.parse(e.ExecutionDate)),
            noOfTransactions: e.NoOfTrxEachDay
          }
        })
        break;
      default:
        break;
    }
    return data;
  }

  renderChart(data: { executionDate: Date, noOfTransactions: number }[]) {
    // Chart rendering code goes here
    console.log('data', data);
    const chart = c3.generate({
      bindto: '#chart',
      data: {
        json: data,
        keys: {
          x: 'executionDate',
          value: ['noOfTransactions']
        },
        type: 'line'
      },
      axis: {
        x: {
          type: 'timeseries',
          tick: {
            format: '%Y-%m-%d' // Format the x-axis tick values
          }
        },
        y: {
          tick: {
            format: d3.format('d') // Format the y-axis tick values
          }
        }
      }
    });
  }
  /*   ngAfterViewInit() {
      setTimeout(function () {
        chart.load({
            columns:[
                ['data2', null, 30, 20, 50, 40, 60, 50]
            ]
        });
    }, 6000); */
  /* let chart = c3.generate({
    bindto: '#chart',
    data: {
      columns: [
        ['data1', 30, 200, 100, 400, 150, 250, 500],
        ['data2', 50, 20, 10, 40, 15, 25]
      ],
      axes: {
        data2: 'y2'
      },
    },
    axis: {
      y: {
        label: {
          text: 'Y Label',
          position: 'outer-middle'
        },
        tick: {
          format: d3.format("$,") // ADD
        }
      },
      y2: {
        show: true,
        label: {
          text: 'Y2 Label',
          position: 'outer-middle'
        }
      }
    }
  }); */
}

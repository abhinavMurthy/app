const express = require('express');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(express.json());
app.use(cors());

app.get('/users', (req, res) => {
  const users = generateUsers(10); // Generate 10 mock users
  res.json(users);
});

app.get('/users/:id', (req, res) => {
  const users = generateChartData();
  const userId = parseInt(req.params.id);
  const user = users.find(user => user.ClientName === userId);

  if (user) {
    res.json(user);
  } else {
    res.status(404).json({ message: 'User not found' });
  }
});

app.listen(port, () => {
  console.log(`Mock User Service is running on port ${port}`);
});

function generateUsers(count) {
  const users = [];
  for (let i = 0; i < count; i++) {
    const user = {
      ClientName: 10000 + i,
      NoOfTransaction: 123 + i,
      TotalAmount: Math.round(1234 * Math.random()),
      Currency: 'SGD',
      RiskIndicator: 1,
      Anamoly: 'transactions',
      Variation: 50
    };
    users.push(user);
  }
  return users;
}

function generateChartData() {
  const users = [];
  var today = new Date();
  for (let i = 0; i < 10; i++) {
    const user = {
      ClientName: 10000 + i,
      AnomalyType: 'transactions',
      Data: [{
        ExecutionDate: new Date(),
        NoOfTrxEachDay: 222 + i,
        IndividualAmount: 4563 * i,
        AuthorizationDate: new Date(),
      },
      {
        ExecutionDate: new Date(new Date().setDate(today.getDate() - 30)),
        NoOfTrxEachDay: 222 * 2,
        IndividualAmount: 4563 * i * 3,
        AuthorizationDate: new Date(new Date().setDate(today.getDate() - 300)),
      },
      {
        ExecutionDate: new Date(new Date().setDate(today.getDate() - 20)),
        NoOfTrxEachDay: 222 * 2,
        IndividualAmount: 4563 * i * 3,
        AuthorizationDate: new Date(new Date().setDate(today.getDate() - 35)),
      },
      {
        ExecutionDate: new Date(new Date().setDate(today.getDate() - 40)),
        NoOfTrxEachDay: 222 * 2,
        IndividualAmount: 4563 * i * 3,
        AuthorizationDate: new Date(new Date().setDate(today.getDate() - 34)),
      },
      {
        ExecutionDate: new Date(new Date().setDate(today.getDate() - 67)),
        NoOfTrxEachDay: 222 * 2,
        IndividualAmount: 4563 * i * 3,
        AuthorizationDate: new Date(new Date().setDate(today.getDate() - 99)),
      },
      {
        ExecutionDate: new Date(new Date().setDate(today.getDate() - 100)),
        NoOfTrxEachDay: 222 * 2,
        IndividualAmount: 4563 * i * 3,
        AuthorizationDate: new Date(new Date().setDate(today.getDate() - 200)),
      }
      ]
    };
    users.push(user);
  }
  return users;
}